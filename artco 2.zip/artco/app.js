const express = require('express')
const bodyparser = require('body-parser')
const request = require("request");
const path = require('path')
const https = require("https")
const ejs = require('ejs')
const mongoose = require('mongoose')
const multer = require('multer')
    // Mongodb connection URL
mongoose.connect("mongodb://localhost:27017/users_artco", { useNewUrlParser: true })

// managing the storage 

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'images')
    },
    filename: (req, file, cb) => {
        console.log(file)
        cb(null, Date.now() + path.extname(file.originalname))
    }
})

const upload = multer({ storage: storage })
    // Mongodb Schema
const userSchema = new mongoose.Schema({
    name: String,
    location: String,
    caption: String
});
// Mongodb Model
const User = mongoose.model("User", userSchema)
const app = express();
app.set('view engine', 'ejs')
app.use(express.static(__dirname + '/public/'));
app.use(bodyparser.urlencoded({ extended: true }))

// Home route logic

app.get("/", function(req, res) {

    User.find({}, function(err, cardsdata) {
        res.render("index", {
            posts: cardsdata
        });
    });
});

// Add page get route

app.get("/add", function(req, res) {
    res.render("add")
})

// Add page post route logic

app.post("/add.ejs", upload.single("image"), function(req, res) {
    const userName = req.body.username
    const userLocation = req.body.userlocation
    const userCaption = req.body.usercaption

    const data = new User({
        name: userName,
        location: userLocation,
        caption: userCaption
    })
    data.save()

    res.redirect("/")

})


app.listen(8000, function() {
    console.log("server is running on port 8000");
})